package com.techblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechblogBackened1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

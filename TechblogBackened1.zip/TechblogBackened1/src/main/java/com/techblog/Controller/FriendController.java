package com.techblog.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class FriendController {

}

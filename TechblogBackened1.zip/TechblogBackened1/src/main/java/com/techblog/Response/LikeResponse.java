package com.techblog.Response;

public class LikeResponse {
	
	private Long count;
	private Boolean isLike;
	public LikeResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	public Boolean getIsLike() {
		return isLike;
	}
	public void setIsLike(Boolean isLike) {
		this.isLike = isLike;
	}
	
	

}

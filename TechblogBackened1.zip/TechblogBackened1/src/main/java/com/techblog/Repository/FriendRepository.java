package com.techblog.Repository;

import org.springframework.stereotype.Repository;

@Repository
public interface FriendRepository {

}

package com.techblog.Request;

public class AddFriendRequest {

}
